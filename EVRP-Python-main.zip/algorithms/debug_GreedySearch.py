
from copy import deepcopy
from random import shuffle
import time
from random import choice
from loguru import logger
import numpy as np
from objects.debug_problem import Problem
from objects.debug_solution import Solution


class GreedySearch():
    """
    Algorithm for insert energy stations into all tours for each vehicle.
    
    """
    def __init__(self) -> None:
        pass

    def set_problem(self, problem: Problem):
        self.problem = problem
        self.nearest_dist_customer_matrix = {}
        self.calc_nearest_dist_customer_matrix()
        

    def free(self):
        pass
    
    def init_solution(self) -> Solution:
        solution = self.stochastic_greedy_solution()
        logger.debug(f"[InitSolution] stochastic_greedy => {solution}")
        return solution
    
    def optimize(self, solution: Solution) -> Solution:
        logger.debug(f"[Optimize] Initial solution =>\n{solution}")
        solution = self.local_search(solution)
        logger.debug(f"[Optimize] After local_search =>\n{solution}")
        solution = self.insert_depots(solution)
        logger.debug(f"[Optimize] After insert_depots =>\n{solution}")
        solution.set_tour_length(self.problem.calculate_tour_length(solution))
        logger.debug(f"[Optimize] Final => length={solution.get_tour_length()}, route:\n{solution}")
        return solution

    def solve(self, problem, verbose=False) -> Solution:
        self.set_problem(problem)
        self.verbose = verbose
        solution = self.init_solution()
        solution = self.optimize(solution)
        return solution
    
    def calc_nearest_dist_customer_matrix(self):
        all_customers = self.problem.get_all_customers()
        self.nearest_dist_customer_matrix = {}
        
        for i in range(len(all_customers)):
            distances = []
            for j in range(len(all_customers)):
                distances.append(all_customers[i].distance(all_customers[j]))
            argsort_dist = np.argsort(distances)
            self.nearest_dist_customer_matrix[all_customers[i].get_id()] = \
                [all_customers[j].get_id() for j in argsort_dist if i != j]
                
                
            
    def stochastic_greedy_solution(self, k=3) -> Solution:
            """
            - stochastic greedy로 초기 해 생성
            - k-nearest customer를 무작위로 선택해 투어 구성
            """
            solution = Solution()
            cust_ids = self.problem.get_customer_ids()
            depot = self.problem.get_depot()

            current_load = self.problem.get_capacity()
            current_energy = self.problem.get_battery_capacity()
            tour = [depot]

            if cust_ids:
                first_customer_id = choice(cust_ids)
                first_customer = self.problem.get_node_from_id(first_customer_id)
                needed_to_first = self.problem.get_energy_consumption(depot, first_customer)

                tour.append(first_customer)
                cust_ids.remove(first_customer_id)
                current_load -= first_customer.get_demand()
                current_energy -= needed_to_first

            while cust_ids:
                current_node = tour[-1]
                distances = [(cid, self.problem.get_distance(current_node, self.problem.get_node_from_id(cid))) for cid in cust_ids]
                distances.sort(key=lambda x: x[1])
                k_nearest = [cid for cid, _ in distances[:k]]

                found_next = False
                for next_customer_id in k_nearest:
                    next_customer = self.problem.get_node_from_id(next_customer_id)
                    demand = next_customer.get_demand()

                    needed_to_next = self.problem.get_energy_consumption(current_node, next_customer)
                    needed_to_depot = self.problem.get_energy_consumption(next_customer, depot)
                    total_needed = needed_to_next + needed_to_depot

                    if demand <= current_load and total_needed <= current_energy:
                        tour.append(next_customer)
                        cust_ids.remove(next_customer_id)
                        current_load -= demand
                        current_energy -= needed_to_next
                        found_next = True
                        break

                if not found_next:
                    tour.append(depot)
                    current_load = self.problem.get_capacity()
                    current_energy = self.problem.get_battery_capacity()

                    if cust_ids:
                        next_start_customer_id = choice(cust_ids)
                        next_start_customer = self.problem.get_node_from_id(next_start_customer_id)
                        tour.append(next_start_customer)
                        cust_ids.remove(next_start_customer_id)
                        current_load -= next_start_customer.get_demand()
                        current_energy -= self.problem.get_energy_consumption(depot, next_start_customer)

            if tour[-1] != depot:
                tour.append(depot)

            solution.add_tour(tour)
            solution.set_tour_index()
            return solution



    def local_search(self, solution: Solution) -> Solution:
        """
        예시:
        - solution.tours 안에 여러 sub-route가 있음.
        - 각 sub-route마다 depot(0)은 앞뒤에 있다고 가정 [0, c1, c2, ..., 0].
        - 이 sub-route에서 '고객 부분'만 추출 -> 2-opt 수행 -> 다시 depot 붙여서 갱신.
        - 최종적으로 solution.tours는 여러 라우트 형태를 그대로 보존.
        """

        # 1) 현재 solution에 있는 여러 라우트(sub-route)를 불러옴
        #    예: [[0,4,0], [0,8,6,0], [0,9,7,5,0], ...]
        multi_tours = solution.get_tours()
        # 만약 .get_basic_tours()를 사용하면 depot이 빠져버리므로,
        # 여기서는 depot 포함된 상태로 라우트를 직접 수정하겠다.

        # 2) 각 sub-route별로 로컬서치(2-opt) 적용
        for route_idx, route in enumerate(multi_tours):
            # route 예: [0, c1, c2, c3, 0]
            if len(route) <= 2:
                # 고객이 0~1명인 sub-route면 2-opt 할게 없음
                continue

            # A) depot을 임시 제거:  route[0], route[-1]이 depot이라고 가정
            #    고객 부분만 추출
            inner_customers = route[1:-1]  # ex: [c1, c2, c3]

            # B) 2-opt 수행
            improved_customers = self.local_search_2opt(inner_customers)

            # C) depot 다시 붙임
            new_subroute = [route[0]] + improved_customers + [route[-1]]

            # D) 기존 sub-route 갱신
            multi_tours[route_idx] = new_subroute

        # 3) solution에 다시 반영
        solution.tours = multi_tours
        solution.set_tour_index()
        return solution




    def local_search_2opt(self, customer_list):
        """
        간단 2-opt 예시:
        - customers_list는 depot 제외된 고객들의 순서
        - 2-opt로 더 짧아질 경우 swap.
        - 예시 구현이므로, 실제론 while 루프 돌며 improvement 없을 때까지 반복하는 방식 등 사용.
        """
        improved = True
        best_route = customer_list[:]
        best_distance = self.route_distance(best_route)
        
        while improved:
            improved = False
            for i in range(len(best_route) - 2):
                for j in range(i+2, len(best_route)):
                    if j - i == 1: 
                        continue
                    new_route = best_route[:]
                    new_route[i:j] = reversed(new_route[i:j])
                    
                    new_dist = self.route_distance(new_route)
                    if new_dist < best_distance:
                        best_route = new_route
                        best_distance = new_dist
                        improved = True
                        break
                if improved:
                    break
        return best_route

    def route_distance(self, customers):
        """
        depot 제외한 순서의 거리 계산:
        - 만약 실제로는 depot~customer도 필요하다면 별도 인자로 depot ID/Node를 붙여서 계산해야 함.
        - 여기서는 "customers만"의 내부 거리합을 예시로 계산.
        """
        dist = 0.0
        for i in range(len(customers) - 1):
            dist += customers[i].distance(customers[i+1])
        return dist
    
    def insert_depots(self, solution: Solution) -> Solution:
        """
        Insert depots into the tour based on battery and capacity constraints.
        """

        depot = self.problem.get_depot()
        full_tour = [depot]
        capacity = self.problem.get_capacity()
        energy = self.problem.get_battery_capacity()

        for node in solution.get_basic_tours()[0]:
            demand = node.get_demand()
            prev_node = full_tour[-1]

            needed_energy = self.problem.get_energy_consumption(prev_node, node)
            return_energy = self.problem.get_energy_consumption(node, depot)

            if demand > capacity or (needed_energy + return_energy) > energy:
                # depot 삽입
                full_tour.append(depot)
                capacity = self.problem.get_capacity()
                energy = self.problem.get_battery_capacity()

            full_tour.append(node)
            capacity -= demand
            energy -= needed_energy

        if full_tour[-1] != depot:
            full_tour.append(depot)

        solution.set_tour(full_tour)
        return solution

    