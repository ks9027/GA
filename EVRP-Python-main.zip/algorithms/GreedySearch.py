
from copy import deepcopy
from random import shuffle
import time
import random
from loguru import logger
import numpy as np
from objects.problem import Problem
from objects.solution import Solution


class GreedySearch():
    """
    Algorithm for insert energy stations into all tours for each vehicle.
    
    """
    def __init__(self) -> None:
        pass

    def set_problem(self, problem: Problem):
        self.problem = problem
        self.nearest_dist_customer_matrix = {}
        self.calc_nearest_dist_customer_matrix()

    def free(self):
        pass
    
    def init_solution(self) -> Solution:
        if random.random() < 0.9:
            # 90% 확률로 무작위 해 생성
            solution = self.problem.random_solution()
        else:
            # 10% 확률로 탐욕적 해 생성
            solution = self.stochastic_greedy_solution()
        return solution
    
    def optimize(self, solution: Solution) -> Solution:
        solution = self.local_search(solution)
        solution = self.insert_depots(solution)
        solution = self.greedy_optimize_depot(solution)
        solution.set_tour_length(self.problem.calculate_tour_length(solution))
        return solution

    def solve(self, problem, verbose=False) -> Solution:
        self.set_problem(problem)
        self.verbose = verbose
        solution = self.init_solution()
        solution = self.optimize(solution)
        return solution
    
    def calc_nearest_dist_customer_matrix(self):
        all_customers = self.problem.get_all_customers()
        self.nearest_dist_customer_matrix = {}
        
        for i in range(len(all_customers)):
            distances = []
            for j in range(len(all_customers)):
                distances.append(all_customers[i].distance(all_customers[j]))
            argsort_dist = np.argsort(distances)
            self.nearest_dist_customer_matrix[all_customers[i].get_id()] = \
                [all_customers[j].get_id() for j in argsort_dist if i != j]
                
                
            
    def stochastic_greedy_solution(self, k=3) -> Solution:
        solution = Solution()
        node_list = self.problem.get_customer_ids()
        depot = self.problem.get_depot()

        current_capacity = self.problem.get_capacity()
        current_energy = self.problem.get_battery_capacity()

        tour = [depot]
        
        while node_list:
            # 현재 위치
            current_node = tour[-1]
            
            # 가까운 고객 k명 선택
            candidate_nodes = self.nearest_dist_customer_matrix[current_node.get_id()][:k]
            valid_candidates = [n for n in candidate_nodes if n in node_list]
            
            if not valid_candidates:
                # 더 이상 방문할 고객이 없으면 depot으로 복귀
                tour.append(depot)
                break

            # k명 중에서 무작위로 1명 선택
            next_node_id = random.choice(valid_candidates)
            next_node = self.problem.get_node_from_id(next_node_id)

            demand = next_node.get_demand()
            energy_needed = self.problem.get_energy_consumption(current_node, next_node)

            # 용량이나 에너지가 부족하면 depot으로 복귀
            if current_capacity < demand or current_energy < energy_needed:
                tour.append(depot)
                current_capacity = self.problem.get_capacity()
                current_energy = self.problem.get_battery_capacity()
                tour.append(depot)
                continue

            # 고객 방문
            tour.append(next_node)
            node_list.remove(next_node_id)

            # 용량 및 에너지 업데이트
            current_capacity -= demand
            current_energy -= energy_needed

        # 마지막 depot 복귀
        if tour[-1] != depot:
            tour.append(depot)

        solution.add_tour(tour)
        solution.set_tour_index()
        
        return solution

    
    def local_search(self, solution: Solution) -> Solution:
        """
        - 단일 차량/단일 라우트 전제
        - local_search_2opt()로 2-opt 개선
        - 여러 tour가 있다면(오류 등으로 생겼다면) 모두 합쳐 최종적으로 하나의 라우트만 남긴다.
        - set_vehicle_tours() 대신 set_tour() 사용
        """

        # 1) 현재 solution에서 "고객 노드만" 뽑은 tours (원래는 여러 라우트일 수도 있다고 가정)
        tours = solution.get_basic_tours()
        #   예: 만약 solution이 [[depot,1,2,depot],[depot,3,depot]] 식이면,
        #   get_basic_tours() -> [[1,2],[3]]

        # 2) 각 tour에 대해 2-opt 수행
        for i, tour in enumerate(tours):
            tours[i] = self.local_search_2opt(tour)
            # local_search_2opt()는 아래 참고

        # 3) 여러 tour가 존재한다면 모두 이어붙이기
        merged_tour = []
        for t in tours:
            merged_tour.extend(t)  # 그냥 순서대로 붙인다

        # 4) 앞뒤에 depot(유일 충전/출발 지점) 추가
        final_tour = [self.problem.get_depot()] + merged_tour + [self.problem.get_depot()]

        # 5) 단일 투어만 남기도록 solution에 세팅
        solution.set_tour(final_tour)
        solution.set_tour_index()  # 노드 중복 체크 등 인덱스 업데이트

        return solution


    
    def local_search_2opt(self, tour):
        """
        - 'tour'는 고객 노드만 들어 있는 상태라고 가정
        - 2-opt로 경로 개선
        - depot을 임시로 앞뒤에 붙인 뒤, 2-opt 반복
        - 끝나면 다시 떼어낸 결과만 반환
        """
        # 1) depot 앞뒤로 추가
        route = [self.problem.get_depot()] + tour + [self.problem.get_depot()]
        improvement = True

        while improvement:
            improvement = False
            # 2) 모든 (i,j) 페어에 대해 2-opt 검사
            for i in range(1, len(route) - 2):
                for j in range(i + 1, len(route) - 1):
                    if j - i == 1:  # 연속 간선은 skip
                        continue
                    new_route = deepcopy(route)
                    # [i:j] 구간 reverse
                    new_route[i:j] = reversed(new_route[i:j])

                    # 거리 비교
                    old_dist = sum(route[k].distance(route[k+1]) for k in range(len(route)-1))
                    new_dist = sum(new_route[k].distance(new_route[k+1]) for k in range(len(new_route)-1))

                    if new_dist < old_dist:
                        route = new_route
                        improvement = True
                        break
                if improvement:
                    break

        # 3) 맨 앞뒤 depot 제거 -> 고객 노드만 반환
        return route[1:-1]


    
    def insert_depots(self, solution: Solution) -> Solution:
        full_tour = []
        capacity = self.problem.get_capacity()
        energy = self.problem.get_battery_capacity()

        logger.debug(f"Customer tours before depot insertion: {solution.get_basic_tours()}")

        # 투어가 비어 있는 경우 경고 로그만 남기고 계속 진행
        if not solution.get_basic_tours():
            logger.error("No tours found in solution. Proceeding with empty solution.")

        for i, node in enumerate(solution.get_basic_tours()[0]):
            demand = node.get_demand()
            prev_node = full_tour[-1] if full_tour else self.problem.get_depot()

            energy_needed = self.problem.get_energy_consumption(prev_node, node)

            if demand > capacity or energy_needed > energy:
                logger.debug(f"Returning to depot (Capacity: {capacity}, Energy: {energy})")
                full_tour.append(self.problem.get_depot())
                capacity = self.problem.get_capacity()
                energy = self.problem.get_battery_capacity()

            full_tour.append(node)
            capacity -= demand
            energy -= energy_needed

        if full_tour and not full_tour[-1].is_depot():
            full_tour.append(self.problem.get_depot())

        solution.set_tour(full_tour)
        self.greedy_optimize_depot(solution)

        logger.debug(f"Final full tour after depot insertion: {full_tour}")
        return solution

    def greedy_optimize_depot(self, solution: Solution) -> Solution:
        """
        Optimize the position of depots in the entire tour to minimize travel distance.
        This function assumes a single long tour for the vehicle.
        """
        tour = solution.get_tours()[0]  # 단일 투어 가져오기
        
        if len(tour) <= 2:  # depot -> node -> depot 형태이면 최적화 불필요
            return solution
        
        curr_capacity = 0
        curr_energy = 0
        
        for i in reversed(range(len(tour))):
            if i < 2 or i == len(tour) - 1:
                continue

            node = tour[i]
            if node.is_customer():
                curr_capacity += node.get_demand()
                curr_energy += self.problem.get_energy_consumption(tour[i - 1], node)
            
            if node.is_depot():
                c1 = tour[i - 2]
                c2 = tour[i - 1]
                depot = tour[i]
                c3 = tour[i + 1]

                d1 = self.problem.get_distance(c1, c2)
                d2 = self.problem.get_distance(c2, depot)
                d3 = self.problem.get_distance(depot, c3)

                new_d1 = self.problem.get_distance(c1, depot)
                new_d2 = self.problem.get_distance(depot, c2)
                new_d3 = self.problem.get_distance(c2, c3)

                # 배터리 소모량 고려
                energy_condition = self.problem.get_energy_consumption(c1, depot) + \
                                self.problem.get_energy_consumption(depot, c2) + \
                                self.problem.get_energy_consumption(c2, c3) < \
                                self.problem.get_energy_consumption(c1, c2) + \
                                self.problem.get_energy_consumption(c2, depot) + \
                                self.problem.get_energy_consumption(depot, c3)

                # 적재량과 거리 조건
                demand_condition = c2.get_demand() + c3.get_demand() <= self.problem.get_capacity()
                distance_condition = d1 + d2 + d3 > new_d1 + new_d2 + new_d3

                # 두 조건 모두 만족하면 depot 위치 조정
                if demand_condition and distance_condition and energy_condition:
                    tour[i] = c2
                    tour[i - 1] = depot
                    curr_capacity += c2.get_demand()
                    curr_energy += self.problem.get_energy_consumption(c1, c2)
                else:
                    curr_capacity = 0
                    curr_energy = 0
        
        # 최적화된 단일 투어를 solution에 업데이트
        solution.set_tour(tour)
        return solution

